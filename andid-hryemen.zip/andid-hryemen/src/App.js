import React, { useState } from 'react';

function App() {
  const [formData, setFormData] = useState({
    jobTitle: '',
    company: '',
    location: '',
    deadline: '',
    description: '',
    requirements: 'شهادة جامعية\nخبرة لا تقل عن سنتين\nإجادة استخدام الحاسوب\nالقدرة على العمل ضمن فريق'
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    alert('تم إرسال الطلب للمراجعة. سيتم النشر بعد الموافقة.');
  };

  return (
    <div style={{ padding: 20, maxWidth: 700, margin: '0 auto', direction: 'rtl' }}>
      <h1 style={{ textAlign: 'center' }}>Andid HR Yemen</h1>
      <form onSubmit={handleSubmit}>
        <input name="jobTitle" placeholder="المسمى الوظيفي" onChange={handleChange} required /><br/><br/>
        <input name="company" placeholder="اسم الشركة" onChange={handleChange} required /><br/><br/>
        <input name="location" placeholder="الموقع" onChange={handleChange} required /><br/><br/>
        <input name="deadline" type="date" onChange={handleChange} required /><br/><br/>
        <textarea name="description" placeholder="وصف الوظيفة" onChange={handleChange} required /><br/><br/>
        <textarea name="requirements" placeholder="الشروط والمتطلبات" value={formData.requirements} onChange={handleChange} /><br/><br/>
        <button type="submit">إرسال الطلب للمراجعة</button>
      </form>
    </div>
  );
}

export default App;